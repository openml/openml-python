"""
=======
Studies
=======

This is only a placeholder so far.
"""
